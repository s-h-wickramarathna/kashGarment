-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.35 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table kash.adress: ~0 rows (approximately)

-- Dumping data for table kash.city: ~0 rows (approximately)
REPLACE INTO `city` (`ci_id`, `ci_name`, `country_con_id`) VALUES
	(1, 'Matara', 3),
	(2, 'New York', 2),
	(3, 'Tokyo', 1),
	(4, 'Shanghai', 5),
	(5, 'Mumbai', 4);

-- Dumping data for table kash.client: ~0 rows (approximately)
REPLACE INTO `client` (`cl_email`, `cl_fname`, `cl_lname`, `cl_mobile`) VALUES
	('client1@gmail.com', 'client1', 'client1', '0765555555'),
	('client2@gmail.com', 'client2', 'client2', '0765555556');

-- Dumping data for table kash.color: ~0 rows (approximately)
REPLACE INTO `color` (`c_id`, `c_name`) VALUES
	(1, 'Red'),
	(2, 'Blue'),
	(3, 'Pink'),
	(4, 'Yellow'),
	(5, 'Green');

-- Dumping data for table kash.company: ~0 rows (approximately)
REPLACE INTO `company` (`com_id`, `com_name`) VALUES
	(1, 'Kravet'),
	(2, 'Crypton'),
	(3, 'Carole Fabric'),
	(4, 'Barrow'),
	(5, 'Covineton Fabric');

-- Dumping data for table kash.consumption: ~0 rows (approximately)

-- Dumping data for table kash.country: ~0 rows (approximately)
REPLACE INTO `country` (`con_id`, `con_name`) VALUES
	(1, 'Japan'),
	(2, 'America'),
	(3, 'Sri Lanka'),
	(4, 'India'),
	(5, 'China');

-- Dumping data for table kash.employee: ~0 rows (approximately)
REPLACE INTO `employee` (`emp_id`, `emp_fname`, `emp_lname`, `emp_nic`, `emp_mobile`, `emp_joinDate`, `employee_type_empt_id`, `status_s_id`) VALUES
	(1, 'emp1', 'emp1', '200000000001', '0762222222', '2024-05-20', 1, 1),
	(2, 'emp2', 'emp2', '200000000002', '0763333333', '2024-05-20', 4, 1);

-- Dumping data for table kash.employee_type: ~0 rows (approximately)
REPLACE INTO `employee_type` (`empt_id`, `empt_type`) VALUES
	(1, 'Chairmen'),
	(2, 'General Manager'),
	(3, 'Technical Manager'),
	(4, 'Factory Manager'),
	(5, 'Production Manager'),
	(6, 'Quality Assuarence Manager'),
	(7, 'Quality Checker'),
	(8, 'Supervisor'),
	(9, 'Operator'),
	(10, 'Helper');

-- Dumping data for table kash.gender: ~0 rows (approximately)
REPLACE INTO `gender` (`g_id`, `g_type`) VALUES
	(1, 'Male'),
	(2, 'Female');

-- Dumping data for table kash.grn: ~0 rows (approximately)
REPLACE INTO `grn` (`grn_id`, `grn_total_price`, `supplier_sup_id`, `grn_purchesed_date`, `user_u_id`) VALUES
	(1, 2500, 1, '2024-05-20', 1);

-- Dumping data for table kash.grn_item: ~0 rows (approximately)
REPLACE INTO `grn_item` (`grni_id`, `unit_buy_price`, `grni_qty`, `stock_stock_id`, `grn_grn_id`) VALUES
	(1, 65, 100, 4, 1);

-- Dumping data for table kash.invoice: ~0 rows (approximately)
REPLACE INTO `invoice` (`in_id`, `in_purchesed_date`, `in_total_price`, `user_u_id`) VALUES
	('#saf4xv', '2024-05-20', 250000, 1);

-- Dumping data for table kash.invoice_item: ~0 rows (approximately)
REPLACE INTO `invoice_item` (`init_id`, `product_details_pd_id`, `invoice_in_id`) VALUES
	(1, '#da45vc', '#saf4xv');

-- Dumping data for table kash.material: ~0 rows (approximately)
REPLACE INTO `material` (`m_id`, `m_name`, `m_description`, `material_type_mt_id`) VALUES
	(1, 'Collor Button', 'yellow Collor Button', 1),
	(2, 'Cotton Fabric', 'Full Cotton Fabric', 2),
	(3, '1\'\' Ilustic', 'Rubber Illustic', 4),
	(4, 'Single Thread', 'Red Single Thread', 3),
	(5, 'Gold Zipper', 'Fat Gold Zipper', 5);

-- Dumping data for table kash.material_color: ~5 rows (approximately)
REPLACE INTO `material_color` (`mc_id`, `material_m_id`, `color_c_id`) VALUES
	(1, 3, 2),
	(2, 1, 5),
	(3, 2, 3),
	(4, 5, 1),
	(5, 4, 4);

-- Dumping data for table kash.material_type: ~0 rows (approximately)
REPLACE INTO `material_type` (`mt_id`, `mt_name`) VALUES
	(1, 'Button'),
	(2, 'Fabric'),
	(3, 'Thread'),
	(4, 'Ilustic'),
	(5, 'Zipper');

-- Dumping data for table kash.product: ~0 rows (approximately)
REPLACE INTO `product` (`p_id`, `p_name`, `p_description`, `client_cl_email`) VALUES
	(1, 'Ladies Frock', 'ladies Long Sleves Frock', 'client1@gmail.com'),
	(2, 'Gents Short', 'Cargo Pocket Gents Shorts', 'client2@gmail.com');

-- Dumping data for table kash.product_color: ~0 rows (approximately)
REPLACE INTO `product_color` (`pc_id`, `product_p_id`, `color_c_id`) VALUES
	(1, 2, 2),
	(2, 1, 5);

-- Dumping data for table kash.product_details: ~0 rows (approximately)
REPLACE INTO `product_details` (`pd_id`, `product_p_id`, `start_date`, `end_date`, `shipping_date`, `shipping_status_ship_id`, `pd_qty`, `pd_unit_price`, `pd_damage_items`) VALUES
	('#da45vc', 1, '2024-05-20', '2024-07-20', '2024-07-25', 1, 500, 1000, 0),
	('#sa32ew', 2, '2024-05-21', '2024-06-20', '2024-05-27', 1, 200, 450, 2);

-- Dumping data for table kash.product_size: ~0 rows (approximately)
REPLACE INTO `product_size` (`ps_id`, `size_s_id`, `product_p_id`) VALUES
	(1, 3, 2),
	(2, 2, 2),
	(3, 4, 1),
	(4, 5, 1);

-- Dumping data for table kash.product_state: ~0 rows (approximately)
REPLACE INTO `product_state` (`ps_id`, `state_st_id`, `product_details_pd_id`) VALUES
	(1, 5, '#da45vc'),
	(2, 7, '#sa32ew');

-- Dumping data for table kash.shipping_status: ~0 rows (approximately)
REPLACE INTO `shipping_status` (`ship_id`, `ship_name`) VALUES
	(1, 'Not Shiped Yet'),
	(2, 'Shiped');

-- Dumping data for table kash.size: ~0 rows (approximately)
REPLACE INTO `size` (`s_id`, `s_name`) VALUES
	(1, 'S'),
	(2, 'M'),
	(3, 'L'),
	(4, 'XL'),
	(5, 'XXL');

-- Dumping data for table kash.state: ~0 rows (approximately)
REPLACE INTO `state` (`st_id`, `st_name`) VALUES
	(1, 'Not Start'),
	(2, 'Cutting'),
	(3, 'Print'),
	(4, 'Sawing'),
	(5, 'Checking'),
	(6, 'Washing'),
	(7, 'Packing'),
	(8, 'Finish');

-- Dumping data for table kash.status: ~0 rows (approximately)
REPLACE INTO `status` (`s_id`, `s_type`) VALUES
	(1, 'Active'),
	(2, 'Inactive');

-- Dumping data for table kash.stock: ~0 rows (approximately)
REPLACE INTO `stock` (`stock_id`, `material_m_id`, `stock_qty`, `stock_unitPrice`, `stock_date`, `stock_damage_item`) VALUES
	(1, 3, 100, 25, '2024-05-20', 0),
	(2, 1, 250, 3, '2024-05-20', 0),
	(3, 2, 80, 25000, '2024-05-20', 0),
	(4, 5, 500, 130, '2024-05-20', 0),
	(5, 4, 700, 70, '2024-05-20', 0);

-- Dumping data for table kash.supplier: ~0 rows (approximately)
REPLACE INTO `supplier` (`sup_id`, `sup_fname`, `sup_lname`, `sup_mobile`, `sup_email`, `company_com_id`) VALUES
	(1, 'sup1', 'sup1', '0762222222', 'sup@gmail.com', 4),
	(2, 'sup2', 'sup2', '0763333333', 'sup2@gmail.com', 1);

-- Dumping data for table kash.user: ~0 rows (approximately)
REPLACE INTO `user` (`u_id`, `u_password`, `employee_emp_id`) VALUES
	(1, '123456', 1),
	(2, '123456', 2);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
