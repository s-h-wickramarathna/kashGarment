package datechooser;

import java.awt.event.MouseEvent;

public interface Event {

    public void execute(MouseEvent evt, int num);
}
