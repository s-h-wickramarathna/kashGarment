package Model;


public class EmployeeBean {
 
    private String emp_id;
    private String emp_fname;
    private String emp_lname;
    private String emp_nic;
    private String emp_mobile;
    private String emp_joinDate;
    private String employee_type_empt_id;
    private String status_s_id;
    private String u_id;
    private String employeeType;

    public String getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(String emp_id) {
        this.emp_id = emp_id;
    }

    public String getEmp_fname() {
        return emp_fname;
    }

    public void setEmp_fname(String emp_fname) {
        this.emp_fname = emp_fname;
    }

    public String getEmp_lname() {
        return emp_lname;
    }

    public void setEmp_lname(String emp_lname) {
        this.emp_lname = emp_lname;
    }

    public String getEmp_nic() {
        return emp_nic;
    }

    public void setEmp_nic(String emp_nic) {
        this.emp_nic = emp_nic;
    }

    public String getEmp_mobile() {
        return emp_mobile;
    }

    public void setEmp_mobile(String emp_mobile) {
        this.emp_mobile = emp_mobile;
    }

    public String getEmp_joinDate() {
        return emp_joinDate;
    }

    public void setEmp_joinDate(String emp_joinDate) {
        this.emp_joinDate = emp_joinDate;
    }

    public String getEmployee_type_empt_id() {
        return employee_type_empt_id;
    }

    public void setEmployee_type_empt_id(String employee_type_empt_id) {
        this.employee_type_empt_id = employee_type_empt_id;
    }

    public String getStatus_s_id() {
        return status_s_id;
    }

    public void setStatus_s_id(String status_s_id) {
        this.status_s_id = status_s_id;
    }

    public String getU_id() {
        return u_id;
    }

    public void setU_id(String u_id) {
        this.u_id = u_id;
    }

    public String getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(String employeeType) {
        this.employeeType = employeeType;
    }
    
}
